package br.com.controller;
import br.com.model.Evento;
import br.com.model.Processo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * 
 * @author nakao<nakaosensei@gmail.com>
 * 
 */
public class ProcessController {
    private int numProcessos;
    private int prioridadeMinima;
    private int prioridadeMaxima;
    private List<Processo> processos;
    private HashMap<Long,Processo> mapaProcessos;
    private long tempoRelogio;
    public long nextInitTime;
    public ProcessController(String arq){
        carregarEstruturas(arq);        
        
    }
    
  
    private void carregarEstruturas(String arq){
        String v[]=arq.split("\n");
        processos=new ArrayList<>();
        mapaProcessos = new HashMap<>();
        numProcessos=Integer.parseInt(v[0].trim());
        String prioridadeSplit[]=v[1].trim().split("-");
        prioridadeMinima=Integer.parseInt(prioridadeSplit[0].trim());
        prioridadeMaxima=Integer.parseInt(prioridadeSplit[1].trim());
        String s="";
        for(int i = 2;i<=v.length-1;i++){
            s+=v[i]+"\n";
            if(v[i].contains("TERMINO")){
                Processo p = new Processo(s);                
                s="";
                this.processos.add(p);                
                mapaProcessos.put(p.getInicio().getTempoOcorrencia(), p);
            }
        }
        this.orderProcessesCreationByTime();
        nextInitTime=this.processos.get(0).getInicio().getTempoOcorrencia();
    }

    public void orderProcessesCreationByTime(){
        Collections.sort (this.processos, new Comparator() {
            public int compare(Object o1, Object o2) {
                Processo p1 = (Processo) o1;
                Processo p2 = (Processo) o2;
                return p1.getInicio().getTempoOcorrencia()< p2.getInicio().getTempoOcorrencia() ? -1 : (p1.getInicio().getTempoOcorrencia() > p2.getInicio().getTempoOcorrencia() ? +1 : 0);
            }
        });
    }    
    
    
    
    
    public Processo binarySearch(long tempo){
        System.out.println("Binary Search Time:"+tempo);
        int posIni=0;
        int posFim=numProcessos-1;
        while(posFim>=posIni){
            int pmid = (posIni+posFim)/2;
            Processo meio = processos.get(pmid);
            if(tempo==meio.getInicio().getTempoOcorrencia()){
                return meio;
            }else if(posIni==posFim){
                return null;
            }else if(tempo>meio.getInicio().getTempoOcorrencia()){
                posIni=pmid;
            }else{
                posFim=pmid;
            }            
        }     
        return null;
    }
    
    public void add(Processo p){
        this.processos.add(p);
    }
    
    public void remove(Processo p){
        this.processos.remove(p);
    }
    
    public void print(){
        System.out.println("Qtde Processos: "+this.numProcessos+" Prioridade Minima: "+prioridadeMinima +" Prioridade Maxima: "+this.prioridadeMaxima);
        System.out.println("Processos:");
        for(Processo p:this.processos){
            p.println();System.out.println("");
        }
    }
    
    public Processo getWhoArrivedAttUnit(long time){
        return mapaProcessos.get(time);
    }
    
    public List<Processo> getWhoArrivedAtt(long time){
        List<Processo> arrived=new ArrayList<>();         
       for(Processo p:this.processos){
            if(p.getInicio().getTempoOcorrencia()==time){
                arrived.add(p);
            }
        }
        return arrived;        
    }
    
    public boolean contains(Processo p){
        if(this.processos.contains(p)){
            return true;
        }else{
            return false;
        }
    }
    
    public int getNumProcessos() {
        return numProcessos;
    }

    public void setNumProcessos(int numProcessos) {
        this.numProcessos = numProcessos;
    }

    public int getPrioridadeMinima() {
        return prioridadeMinima;
    }

    public void setPrioridadeMinima(int prioridadeMinima) {
        this.prioridadeMinima = prioridadeMinima;
    }

    public int getPrioridadeMaxima() {
        return prioridadeMaxima;
    }

    public void setPrioridadeMaxima(int prioridadeMaxima) {
        this.prioridadeMaxima = prioridadeMaxima;
    }

    public List<Processo> getProcessos() {
        return processos;
    }

    public void setProcessos(List<Processo> processos) {
        this.processos = processos;
    }

    public Processo getEvtOwner(Evento e){
        for(Processo p:this.processos){
            if(p.getPid()==e.getOwnerId()){
                return p;
            }
        }
        return null;
    }
}
