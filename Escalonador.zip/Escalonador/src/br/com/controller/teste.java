/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.controller;

import java.util.HashMap;

/**
 *
 * @author nakao<nakaosensei@gmail.com>
 */
public class teste {
    public static void main(String[] args) {
            HashMap<String,String> a = new HashMap<>();
            String o = a.get("oi");
            System.out.println(o);
    }
   
}
