package br.com.model.politics;

import br.com.model.Processo;
import java.util.List;

/**
 *
 * @author nakao<nakaosensei@gmail.com>
 */
public abstract class Politica {
    protected String nome;
    protected long quantum;
    
    public Politica(String nome,long quantum){
        this.nome=nome;
        this.quantum=quantum;
    }
    
    public abstract Processo doSelectionPolitic(List<Processo> prontos);
    
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getQuantum() {
        return quantum;
    }

    public void setQuantum(long quantum) {
        this.quantum = quantum;
    }

    
    
}
